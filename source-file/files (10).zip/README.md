# Life++ 🧠⚡

**Peer-to-Peer Cognitive Agent Network**

> *Own a persistent AI agent that remembers everything, collaborates with others, and earns while you sleep.*

[![CI](https://github.com/lifeplusplus/core/actions/workflows/ci.yml/badge.svg)](https://github.com/lifeplusplus/core)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.12](https://img.shields.io/badge/Python-3.12-green.svg)](https://python.org)
[![Next.js 14](https://img.shields.io/badge/Next.js-14-black.svg)](https://nextjs.org)

---

## Architecture Overview

```
┌──────────────────────────────────────────────────────────┐
│                    Next.js 14 Frontend                    │
│         TypeScript · TailwindCSS · React Query           │
├──────────────────────────────────────────────────────────┤
│                   FastAPI Backend (Python)                │
│         Agents · Memory · Tasks · Network · Auth         │
├──────────────────────────────────────────────────────────┤
│              PostgreSQL + pgvector  |  Redis              │
│        Relational data + embeddings | Cache + queues      │
└──────────────────────────────────────────────────────────┘
```

## Repository Structure

```
lifeplusplus/
│
├── backend/                    # Python FastAPI service
│   ├── main.py                 # App entry point, middleware, router registration
│   ├── app/
│   │   ├── api/v1/
│   │   │   ├── endpoints/
│   │   │   │   ├── agents.py   # CRUD, chat, stream endpoints
│   │   │   │   ├── memories.py # Store, search, consolidate
│   │   │   │   ├── tasks.py    # Create, list, cancel tasks
│   │   │   │   └── network.py  # Graph, stats, auth
│   │   │   └── deps.py         # JWT auth dependency
│   │   ├── agents/
│   │   │   └── runtime/
│   │   │       └── agent_runtime.py  # LLM + tool loop (Anthropic SDK)
│   │   ├── core/
│   │   │   └── config.py       # Pydantic Settings (12-factor)
│   │   ├── db/
│   │   │   └── session.py      # SQLAlchemy async session factory
│   │   ├── models/
│   │   │   └── models.py       # ORM models (User, Agent, Memory, Task…)
│   │   ├── schemas/
│   │   │   └── schemas.py      # Pydantic request/response schemas
│   │   └── services/
│   │       ├── agent_service.py   # Agent CRUD business logic
│   │       └── memory_service.py  # Vector search, decay, consolidation
│   ├── requirements.txt
│   └── Dockerfile
│
├── frontend/                   # Next.js 14 App Router
│   ├── src/
│   │   ├── app/
│   │   │   ├── layout.tsx      # Root layout with providers, fonts
│   │   │   ├── globals.css     # Design tokens + Tailwind base
│   │   │   └── dashboard/
│   │   │       └── page.tsx    # Dashboard page
│   │   ├── components/
│   │   │   ├── agent/
│   │   │   │   └── AgentChat.tsx      # Full chat UI with optimistic updates
│   │   │   ├── network/
│   │   │   │   └── NetworkGraph.tsx   # SVG graph with live data
│   │   │   ├── memory/
│   │   │   │   └── MemoryViewer.tsx   # Memory browser + semantic search
│   │   │   └── ui/
│   │   │       └── Providers.tsx      # ReactQuery + Sonner providers
│   │   ├── hooks/
│   │   │   └── useApi.ts       # All React Query hooks
│   │   ├── lib/
│   │   │   └── api.ts          # Typed fetch API client
│   │   └── types/
│   │       └── index.ts        # TypeScript type definitions
│   ├── package.json
│   ├── next.config.js
│   └── Dockerfile
│
├── database/
│   ├── migrations/
│   │   └── 001_initial_schema.sql  # Full PostgreSQL schema with pgvector
│   └── seeds/
│       └── 001_dev_seed.sql        # Development seed data
│
├── docs/                       # Extended documentation
├── scripts/
│   └── dev-setup.sh            # One-command dev environment setup
├── .github/workflows/
│   └── ci.yml                  # GitHub Actions CI/CD
└── docker-compose.yml          # Full stack orchestration
```

## Quick Start

### Option A: Docker (recommended)

```bash
git clone https://github.com/lifeplusplus/core
cd lifeplusplus

# Copy and configure env
cp backend/.env.example backend/.env
# Edit backend/.env — add ANTHROPIC_API_KEY

# Start everything
docker compose up -d

# Open
open http://localhost:3000       # Frontend
open http://localhost:8000/docs  # API docs
```

### Option B: Local Development

```bash
# One-command setup
chmod +x scripts/dev-setup.sh
./scripts/dev-setup.sh

# Start backend (in one terminal)
cd backend
source .venv/bin/activate
python main.py

# Start frontend (in another terminal)
cd frontend
npm run dev
```

## Environment Variables

### Backend (`backend/.env`)

```env
# Required for live AI responses
ANTHROPIC_API_KEY=sk-ant-...

# Database (auto-configured in Docker)
DATABASE_URL=postgresql+asyncpg://lifeplusplus:lifeplusplus@localhost:5432/lifeplusplus
REDIS_URL=redis://localhost:6379/0

# Security — CHANGE IN PRODUCTION
SECRET_KEY=your-secret-key
JWT_SECRET=your-jwt-secret

# Optional: OpenAI for embeddings
OPENAI_API_KEY=sk-...

# App
ENVIRONMENT=development
DEBUG=true
```

### Frontend (`frontend/.env.local`)

```env
NEXT_PUBLIC_API_URL=http://localhost:8000
```

## API Reference

Full interactive documentation: `http://localhost:8000/docs`

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/v1/auth/register` | Create user account |
| `POST` | `/api/v1/auth/token` | Get JWT access token |
| `POST` | `/api/v1/agents` | Create agent |
| `GET`  | `/api/v1/agents` | List my agents |
| `GET`  | `/api/v1/agents/discover` | Discover public agents |
| `POST` | `/api/v1/agents/{id}/chat` | Chat with memory augmentation |
| `POST` | `/api/v1/agents/{id}/chat/stream` | Streaming chat (SSE) |
| `POST` | `/api/v1/agents/{id}/memories` | Store memory |
| `GET`  | `/api/v1/agents/{id}/memories` | List memories |
| `POST` | `/api/v1/agents/{id}/memories/search` | Semantic memory search |
| `POST` | `/api/v1/agents/{id}/tasks` | Create task |
| `GET`  | `/api/v1/agents/{id}/tasks` | List tasks |
| `GET`  | `/api/v1/network/graph` | Agent network graph |
| `GET`  | `/api/v1/network/stats` | Network statistics |

## Tech Stack

| Layer | Technology | Why |
|-------|-----------|-----|
| Frontend | Next.js 14 (App Router) | SSR, file-based routing, streaming |
| UI | TailwindCSS + custom tokens | Maintainable, no runtime CSS |
| State | React Query v5 | Caching, optimistic updates, SSE |
| Backend | FastAPI + Python 3.12 | Fast, typed, async-native |
| ORM | SQLAlchemy 2.0 async | Typed queries, connection pooling |
| Database | PostgreSQL 16 + pgvector | Relational + vector search in one DB |
| Cache | Redis 7 | Sessions, queues, pub/sub |
| AI | Anthropic Claude SDK | Tool use, streaming, latest models |
| Auth | JWT (PyJWT) | Stateless, scales horizontally |
| DevOps | Docker Compose + GitHub Actions | Reproducible, automated deploys |

## Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feat/my-feature`
3. Commit with conventional commits: `git commit -m "feat: add agent persona editor"`
4. Push and open a PR

## License

MIT — see [LICENSE](LICENSE)

---

*"The internet gave everyone a voice. Life++ gives everyone a mind."*
