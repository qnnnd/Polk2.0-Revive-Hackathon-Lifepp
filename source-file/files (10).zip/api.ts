/**
 * Life++ API Client
 * Typed HTTP client for all backend endpoints.
 * Uses native fetch with automatic auth header injection.
 */

import type {
  Agent,
  AgentCreate,
  AgentListResponse,
  AgentUpdate,
  AuthTokenResponse,
  ChatRequest,
  ChatResponse,
  Memory,
  MemoryCreate,
  MemorySearchRequest,
  MemorySearchResponse,
  NetworkGraph,
  Task,
  TaskCreate,
  TaskListResponse,
  User,
} from "@/types";

const API_BASE = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";
const API_V1 = `${API_BASE}/api/v1`;

// ── Auth Token Storage ────────────────────────────────────────────────────

let _accessToken: string | null = null;

export function setAccessToken(token: string | null) {
  _accessToken = token;
  if (typeof window !== "undefined") {
    if (token) localStorage.setItem("lpp_token", token);
    else localStorage.removeItem("lpp_token");
  }
}

export function getAccessToken(): string | null {
  if (_accessToken) return _accessToken;
  if (typeof window !== "undefined") {
    return localStorage.getItem("lpp_token");
  }
  return null;
}

// ── Core Fetch Wrapper ────────────────────────────────────────────────────

interface FetchOptions extends RequestInit {
  params?: Record<string, string | number | boolean | undefined>;
  auth?: boolean;
}

async function apiFetch<T>(path: string, options: FetchOptions = {}): Promise<T> {
  const { params, auth = true, ...fetchOpts } = options;

  let url = `${API_V1}${path}`;
  if (params) {
    const qs = new URLSearchParams(
      Object.entries(params)
        .filter(([, v]) => v !== undefined)
        .map(([k, v]) => [k, String(v)])
    ).toString();
    if (qs) url += `?${qs}`;
  }

  const headers: Record<string, string> = {
    "Content-Type": "application/json",
    ...(fetchOpts.headers as Record<string, string>),
  };

  if (auth) {
    const token = getAccessToken();
    if (token) headers["Authorization"] = `Bearer ${token}`;
  }

  const response = await fetch(url, { ...fetchOpts, headers });

  if (!response.ok) {
    let detail = `HTTP ${response.status}`;
    try {
      const err = await response.json();
      detail = err.detail ?? detail;
    } catch {}
    throw new ApiError(detail, response.status);
  }

  if (response.status === 204) return undefined as T;
  return response.json() as Promise<T>;
}

export class ApiError extends Error {
  constructor(
    message: string,
    public readonly status: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}

// ── Auth ──────────────────────────────────────────────────────────────────

export const authApi = {
  register: (data: { did: string; username: string; display_name?: string }) =>
    apiFetch<User>("/auth/register", {
      method: "POST",
      body: JSON.stringify(data),
      auth: false,
    }),

  login: (username: string) =>
    apiFetch<AuthTokenResponse>(`/auth/token?username=${username}`, {
      method: "POST",
      auth: false,
    }),
};

// ── Agents ────────────────────────────────────────────────────────────────

export const agentsApi = {
  create: (data: AgentCreate) =>
    apiFetch<Agent>("/agents", { method: "POST", body: JSON.stringify(data) }),

  list: (params?: { page?: number; page_size?: number }) =>
    apiFetch<AgentListResponse>("/agents", { params }),

  discover: (params?: { capability?: string; page?: number; page_size?: number }) =>
    apiFetch<AgentListResponse>("/agents/discover", { params }),

  get: (id: string) =>
    apiFetch<Agent>(`/agents/${id}`),

  update: (id: string, data: AgentUpdate) =>
    apiFetch<Agent>(`/agents/${id}`, { method: "PATCH", body: JSON.stringify(data) }),

  delete: (id: string) =>
    apiFetch<void>(`/agents/${id}`, { method: "DELETE" }),

  chat: (id: string, data: ChatRequest) =>
    apiFetch<ChatResponse>(`/agents/${id}/chat`, { method: "POST", body: JSON.stringify(data) }),

  /** Returns an EventSource for streaming responses */
  chatStream: (id: string, content: string, sessionId?: string) => {
    const token = getAccessToken();
    const url = new URL(`${API_V1}/agents/${id}/chat/stream`);
    const params = new URLSearchParams({ content, ...(sessionId ? { session_id: sessionId } : {}) });
    // POST streaming — use fetch with ReadableStream
    return fetch(`${API_V1}/agents/${id}/chat/stream?${params}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ content, session_id: sessionId, stream: true }),
    });
  },
};

// ── Memories ──────────────────────────────────────────────────────────────

export const memoriesApi = {
  store: (agentId: string, data: MemoryCreate) =>
    apiFetch<Memory>(`/agents/${agentId}/memories`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  list: (agentId: string, params?: { memory_type?: string; page?: number; page_size?: number }) =>
    apiFetch<{ memories: Memory[]; total: number }>(`/agents/${agentId}/memories`, { params }),

  search: (agentId: string, data: MemorySearchRequest) =>
    apiFetch<MemorySearchResponse>(`/agents/${agentId}/memories/search`, {
      method: "POST",
      body: JSON.stringify(data),
    }),

  consolidate: (agentId: string) =>
    apiFetch<{ pruned: number; strengthened: number; total: number }>(
      `/agents/${agentId}/memories/consolidate`,
      { method: "POST" }
    ),
};

// ── Tasks ─────────────────────────────────────────────────────────────────

export const tasksApi = {
  create: (agentId: string, data: TaskCreate) =>
    apiFetch<Task>(`/agents/${agentId}/tasks`, { method: "POST", body: JSON.stringify(data) }),

  list: (agentId: string, params?: { status?: string; page?: number }) =>
    apiFetch<TaskListResponse>(`/agents/${agentId}/tasks`, { params }),

  get: (agentId: string, taskId: string) =>
    apiFetch<Task>(`/agents/${agentId}/tasks/${taskId}`),

  cancel: (agentId: string, taskId: string) =>
    apiFetch<Task>(`/agents/${agentId}/tasks/${taskId}/cancel`, { method: "POST" }),
};

// ── Network ───────────────────────────────────────────────────────────────

export const networkApi = {
  graph: () =>
    apiFetch<NetworkGraph>("/network/graph", { auth: false }),

  stats: () =>
    apiFetch<{ total_agents: number; online_agents: number; network_health: string }>(
      "/network/stats",
      { auth: false }
    ),
};
