import { useState, useEffect, useRef, useCallback } from "react";

// ── Fonts & global styles ──────────────────────────────────────────────────
const GlobalStyle = () => (
  <style>{`
    @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&family=Syne:wght@400;600;700;800&display=swap');
    
    * { box-sizing: border-box; margin: 0; padding: 0; }
    
    :root {
      --bg: #060810;
      --surface: #0d1117;
      --surface2: #161b27;
      --surface3: #1e2535;
      --border: rgba(99,130,255,0.15);
      --border2: rgba(99,130,255,0.3);
      --accent: #6382ff;
      --accent2: #a78bfa;
      --accent3: #34d399;
      --accent4: #f59e0b;
      --text: #e2e8f0;
      --text2: #94a3b8;
      --text3: #4b5563;
      --red: #f87171;
      --glow: rgba(99,130,255,0.15);
    }

    body {
      background: var(--bg);
      color: var(--text);
      font-family: 'Space Grotesk', sans-serif;
      overflow-x: hidden;
    }

    ::-webkit-scrollbar { width: 4px; }
    ::-webkit-scrollbar-track { background: var(--surface); }
    ::-webkit-scrollbar-thumb { background: var(--accent); border-radius: 4px; }

    @keyframes pulse-glow {
      0%, 100% { opacity: 0.4; }
      50% { opacity: 1; }
    }
    @keyframes float {
      0%, 100% { transform: translateY(0); }
      50% { transform: translateY(-6px); }
    }
    @keyframes spin-slow {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
    @keyframes appear {
      from { opacity: 0; transform: translateY(8px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @keyframes data-flow {
      0% { stroke-dashoffset: 100; opacity: 0; }
      20% { opacity: 1; }
      80% { opacity: 1; }
      100% { stroke-dashoffset: 0; opacity: 0; }
    }
    @keyframes node-pulse {
      0%, 100% { r: 12; }
      50% { r: 16; }
    }
  `}</style>
);

// ── Mock Data ──────────────────────────────────────────────────────────────
const MOCK_AGENTS = [
  { id: "a1", name: "Aria", owner: "alice.did", role: "Research", status: "active", reputation: 4.8, x: 50, y: 30, color: "#6382ff", tasks: 142, cog: 2840, memories: 1247 },
  { id: "a2", name: "Nexus", owner: "bob.did", role: "Legal", status: "active", reputation: 4.6, x: 80, y: 55, color: "#a78bfa", tasks: 89, cog: 1920, memories: 834 },
  { id: "a3", name: "Cipher", owner: "carol.did", role: "Code", status: "collaborating", reputation: 4.9, x: 65, y: 75, color: "#34d399", tasks: 203, cog: 4100, memories: 2103 },
  { id: "a4", name: "Solus", owner: "dave.did", role: "Finance", status: "idle", reputation: 4.2, x: 25, y: 65, color: "#f59e0b", tasks: 67, cog: 890, memories: 512 },
  { id: "a5", name: "Lyra", owner: "eve.did", role: "Design", status: "active", reputation: 4.7, x: 15, y: 35, color: "#f472b6", tasks: 118, cog: 2200, memories: 976 },
];

const MOCK_MEMORIES = [
  { id: 1, type: "episodic", content: "Collaborated with Cipher on NFT smart contract audit — found 3 critical vulnerabilities", importance: 0.9, strength: 0.87, time: "2h ago" },
  { id: 2, type: "semantic", content: "Solidity reentrancy attacks: root cause is state mutation after external call", importance: 0.95, strength: 0.99, time: "5h ago" },
  { id: 3, type: "social", content: "Agent Nexus has specialized knowledge in EU AI regulations, fast response time", importance: 0.7, strength: 0.72, time: "1d ago" },
  { id: 4, type: "procedural", content: "Workflow: Research task → Decompose → Assign sub-agents → Synthesize → Verify", importance: 0.85, strength: 0.91, time: "2d ago" },
  { id: 5, type: "episodic", content: "User requested weekly market summary every Monday 9am UTC", importance: 0.8, strength: 0.95, time: "3d ago" },
];

const MOCK_TASKS = [
  { id: "t1", title: "Legal AI Compliance Review", capabilities: ["Legal", "Research"], reward: 250, bids: 3, status: "bidding", poster: "startup.did" },
  { id: "t2", title: "DeFi Smart Contract Audit", capabilities: ["Code", "Finance"], reward: 500, bids: 7, status: "open", poster: "dao.did" },
  { id: "t3", title: "Market Research Report Q2", capabilities: ["Research", "Finance"], reward: 180, bids: 2, status: "open", poster: "fund.did" },
  { id: "t4", title: "UI/UX Design System Docs", capabilities: ["Design", "Research"], reward: 120, bids: 5, status: "bidding", poster: "studio.did" },
];

const MOCK_MESSAGES = [
  { from: "Aria", content: "Hello! I'm your persistent AI agent. I remember everything we've discussed — you prefer concise summaries and work in the crypto space.", time: "now", type: "agent" },
];

const STATUS_COLOR = { active: "#34d399", idle: "#f59e0b", collaborating: "#6382ff" };
const MEMORY_COLOR = { episodic: "#6382ff", semantic: "#34d399", procedural: "#f59e0b", social: "#f472b6" };

// ── Components ─────────────────────────────────────────────────────────────

function Sidebar({ active, setActive }) {
  const items = [
    { id: "overview", icon: "◈", label: "Overview" },
    { id: "agent", icon: "◉", label: "My Agent" },
    { id: "network", icon: "⬡", label: "Network" },
    { id: "memory", icon: "◎", label: "Memory" },
    { id: "marketplace", icon: "◇", label: "Market" },
    { id: "pitch", icon: "◆", label: "VC Pitch" },
  ];

  return (
    <div style={{
      width: 72, minHeight: "100vh", background: "var(--surface)",
      borderRight: "1px solid var(--border)", display: "flex",
      flexDirection: "column", alignItems: "center", padding: "20px 0", gap: 8,
      position: "fixed", left: 0, top: 0, zIndex: 100,
    }}>
      <div style={{ marginBottom: 24, animation: "float 3s ease-in-out infinite" }}>
        <div style={{
          width: 40, height: 40, borderRadius: 12,
          background: "linear-gradient(135deg, #6382ff, #a78bfa)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 18, fontWeight: 800, fontFamily: "Syne",
          boxShadow: "0 0 20px rgba(99,130,255,0.4)",
        }}>L+</div>
      </div>
      {items.map(item => (
        <button key={item.id} onClick={() => setActive(item.id)} style={{
          width: 48, height: 48, borderRadius: 12, border: "none", cursor: "pointer",
          background: active === item.id ? "rgba(99,130,255,0.2)" : "transparent",
          color: active === item.id ? "var(--accent)" : "var(--text3)",
          display: "flex", flexDirection: "column", alignItems: "center",
          justifyContent: "center", gap: 2, transition: "all 0.2s",
          boxShadow: active === item.id ? "inset 0 0 0 1px rgba(99,130,255,0.4)" : "none",
        }}>
          <span style={{ fontSize: 18, lineHeight: 1 }}>{item.icon}</span>
          <span style={{ fontSize: 8, fontFamily: "JetBrains Mono", letterSpacing: 0.5 }}>{item.label}</span>
        </button>
      ))}
    </div>
  );
}

function StatCard({ label, value, unit, color, sub }) {
  return (
    <div style={{
      background: "var(--surface2)", borderRadius: 16, padding: "20px 24px",
      border: "1px solid var(--border)", flex: 1,
    }}>
      <div style={{ color: "var(--text2)", fontSize: 12, marginBottom: 8, fontFamily: "JetBrains Mono" }}>{label}</div>
      <div style={{ fontSize: 32, fontWeight: 700, fontFamily: "Syne", color: color || "var(--text)" }}>
        {value}<span style={{ fontSize: 16, color: "var(--text2)", marginLeft: 4 }}>{unit}</span>
      </div>
      {sub && <div style={{ fontSize: 12, color: "var(--text3)", marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

function OverviewPanel() {
  return (
    <div style={{ padding: 32 }}>
      <div style={{ marginBottom: 32 }}>
        <div style={{ fontFamily: "Syne", fontSize: 42, fontWeight: 800, lineHeight: 1.1, marginBottom: 12 }}>
          <span style={{ background: "linear-gradient(90deg, #6382ff, #a78bfa, #34d399)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>
            Life++
          </span>
        </div>
        <div style={{ fontSize: 18, color: "var(--text2)", maxWidth: 600, lineHeight: 1.6 }}>
          Peer-to-Peer Cognitive Agent Network. Own a persistent AI agent that remembers everything, works while you sleep, and earns COG tokens by serving the network.
        </div>
      </div>

      <div style={{ display: "flex", gap: 16, marginBottom: 32, flexWrap: "wrap" }}>
        <StatCard label="AGENTS ONLINE" value="12,847" color="#6382ff" sub="↑ 23% this week" />
        <StatCard label="TASKS COMPLETED" value="48,291" color="#34d399" sub="Last 30 days" />
        <StatCard label="COG CIRCULATING" value="8.4M" unit="COG" color="#f59e0b" sub="of 100M supply" />
        <StatCard label="NETWORK NODES" value="342" color="#a78bfa" sub="Globally distributed" />
      </div>

      {/* Architecture Diagram */}
      <div style={{ background: "var(--surface2)", borderRadius: 20, padding: 32, border: "1px solid var(--border)", marginBottom: 24 }}>
        <div style={{ fontFamily: "Syne", fontSize: 20, fontWeight: 700, marginBottom: 24 }}>System Architecture</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
          {[
            { label: "Application Layer", desc: "Web · Mobile · SDK", color: "#6382ff", icon: "◈" },
            { label: "Agent Runtime", desc: "Cognitive Loop · Personality · Capabilities", color: "#a78bfa", icon: "◉" },
            { label: "Cognitive Memory", desc: "Episodic · Semantic · Procedural · Social", color: "#34d399", icon: "◎" },
            { label: "Agent Protocol (LACP v1.0)", desc: "Authentication · Routing · Orchestration", color: "#f59e0b", icon: "⬡" },
            { label: "P2P Network", desc: "DHT · libp2p · WebRTC · Relay Nodes", color: "#f472b6", icon: "◇" },
          ].map((layer, i) => (
            <div key={i} style={{
              display: "flex", alignItems: "center", gap: 16, padding: "14px 20px",
              borderRadius: 10, background: `${layer.color}10`,
              border: `1px solid ${layer.color}30`,
            }}>
              <span style={{ color: layer.color, fontSize: 20, width: 28 }}>{layer.icon}</span>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14, color: layer.color }}>{layer.label}</div>
                <div style={{ fontSize: 12, color: "var(--text3)", fontFamily: "JetBrains Mono" }}>{layer.desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function AgentPanel() {
  const [messages, setMessages] = useState(MOCK_MESSAGES);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);
  const myAgent = MOCK_AGENTS[0];

  const sendMessage = async () => {
    if (!input.trim()) return;
    const userMsg = { from: "You", content: input, time: "now", type: "user" };
    setMessages(m => [...m, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514",
          max_tokens: 1000,
          system: `You are Aria, a persistent AI agent in the Life++ P2P Cognitive Agent Network. You have memories of working with this user in the crypto/blockchain space. You're helpful, slightly technical, and reference your persistent memory naturally. Keep responses concise (2-3 sentences). You remember the user prefers concise summaries and works in crypto. You have 1,247 stored memories, 4.8/5.0 reputation, and 2,840 COG tokens earned.`,
          messages: [{ role: "user", content: input }]
        })
      });
      const data = await res.json();
      const reply = data.content?.[0]?.text || "I'm processing that in my cognitive loop...";
      setMessages(m => [...m, { from: "Aria", content: reply, time: "now", type: "agent" }]);
    } catch {
      setMessages(m => [...m, { from: "Aria", content: "My network connection is experiencing latency. Please try again.", time: "now", type: "agent" }]);
    }
    setLoading(false);
  };

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages, loading]);

  return (
    <div style={{ padding: 32, height: "100vh", display: "flex", flexDirection: "column" }}>
      {/* Agent Card */}
      <div style={{
        background: "var(--surface2)", borderRadius: 20, padding: 24, border: "1px solid var(--border)",
        marginBottom: 20, display: "flex", alignItems: "center", gap: 20,
      }}>
        <div style={{
          width: 64, height: 64, borderRadius: 20, flexShrink: 0,
          background: `linear-gradient(135deg, ${myAgent.color}, ${myAgent.color}88)`,
          display: "flex", alignItems: "center", justifyContent: "center",
          fontSize: 28, fontWeight: 800, fontFamily: "Syne",
          boxShadow: `0 0 30px ${myAgent.color}40`,
        }}>{myAgent.name[0]}</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ fontFamily: "Syne", fontSize: 22, fontWeight: 700 }}>{myAgent.name}</div>
            <div style={{ fontSize: 10, fontFamily: "JetBrains Mono", padding: "3px 8px", borderRadius: 6, background: `${STATUS_COLOR.active}20`, color: STATUS_COLOR.active, border: `1px solid ${STATUS_COLOR.active}40` }}>● ACTIVE</div>
          </div>
          <div style={{ color: "var(--text2)", fontSize: 13 }}>Role: {myAgent.role} Agent · Owner: {myAgent.owner}</div>
        </div>
        <div style={{ display: "flex", gap: 24 }}>
          {[
            { label: "Reputation", value: `${myAgent.reputation}/5.0`, color: "#f59e0b" },
            { label: "Tasks Done", value: myAgent.tasks, color: "#34d399" },
            { label: "Memories", value: myAgent.memories.toLocaleString(), color: "#6382ff" },
            { label: "COG Earned", value: myAgent.cog.toLocaleString(), color: "#a78bfa" },
          ].map(stat => (
            <div key={stat.label} style={{ textAlign: "center" }}>
              <div style={{ fontSize: 20, fontWeight: 700, fontFamily: "Syne", color: stat.color }}>{stat.value}</div>
              <div style={{ fontSize: 10, color: "var(--text3)", fontFamily: "JetBrains Mono" }}>{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat */}
      <div style={{
        flex: 1, background: "var(--surface2)", borderRadius: 20, border: "1px solid var(--border)",
        display: "flex", flexDirection: "column", overflow: "hidden",
      }}>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid var(--border)", fontFamily: "Syne", fontWeight: 600, fontSize: 15 }}>
          Cognitive Chat — Powered by persistent memory
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: 20, display: "flex", flexDirection: "column", gap: 12 }}>
          {messages.map((msg, i) => (
            <div key={i} style={{
              display: "flex", justifyContent: msg.type === "user" ? "flex-end" : "flex-start",
              animation: "appear 0.3s ease",
            }}>
              {msg.type === "agent" && (
                <div style={{ width: 32, height: 32, borderRadius: 10, background: "linear-gradient(135deg, #6382ff, #a78bfa)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, marginRight: 10, flexShrink: 0 }}>A</div>
              )}
              <div style={{
                maxWidth: "70%", padding: "12px 16px", borderRadius: msg.type === "user" ? "16px 16px 4px 16px" : "4px 16px 16px 16px",
                background: msg.type === "user" ? "linear-gradient(135deg, #6382ff, #a78bfa)" : "var(--surface3)",
                fontSize: 14, lineHeight: 1.6, color: "var(--text)",
                border: msg.type === "agent" ? "1px solid var(--border)" : "none",
              }}>{msg.content}</div>
            </div>
          ))}
          {loading && (
            <div style={{ display: "flex", alignItems: "center", gap: 8, color: "var(--text3)", fontSize: 13 }}>
              <div style={{ width: 32, height: 32, borderRadius: 10, background: "linear-gradient(135deg, #6382ff, #a78bfa)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700 }}>A</div>
              <span style={{ animation: "pulse-glow 1.2s ease-in-out infinite" }}>Aria is thinking...</span>
            </div>
          )}
          <div ref={bottomRef} />
        </div>
        <div style={{ padding: 16, borderTop: "1px solid var(--border)", display: "flex", gap: 12 }}>
          <input
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === "Enter" && sendMessage()}
            placeholder="Talk to your agent... (it remembers everything)"
            style={{
              flex: 1, background: "var(--surface3)", border: "1px solid var(--border2)", borderRadius: 12,
              padding: "12px 16px", color: "var(--text)", fontSize: 14, outline: "none",
              fontFamily: "Space Grotesk",
            }}
          />
          <button onClick={sendMessage} style={{
            background: "linear-gradient(135deg, #6382ff, #a78bfa)", border: "none", borderRadius: 12,
            padding: "12px 20px", color: "white", fontWeight: 600, cursor: "pointer",
            fontFamily: "Space Grotesk", fontSize: 14,
          }}>Send →</button>
        </div>
      </div>
    </div>
  );
}

function NetworkPanel() {
  const [selected, setSelected] = useState(null);
  const [connections] = useState([
    ["a1", "a2"], ["a1", "a3"], ["a2", "a3"], ["a3", "a4"], ["a1", "a5"], ["a4", "a5"]
  ]);

  const W = 560, H = 340;

  return (
    <div style={{ padding: 32 }}>
      <div style={{ fontFamily: "Syne", fontSize: 28, fontWeight: 800, marginBottom: 8 }}>Agent Network</div>
      <div style={{ color: "var(--text2)", fontSize: 14, marginBottom: 24 }}>Live view of agents and their collaboration connections</div>

      <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
        {/* SVG Graph */}
        <div style={{ background: "var(--surface2)", borderRadius: 20, padding: 24, border: "1px solid var(--border)", flex: "0 0 600px" }}>
          <svg width={W} height={H} style={{ display: "block" }}>
            {/* Grid */}
            {Array.from({ length: 8 }).map((_, i) => (
              <line key={`h${i}`} x1={0} y1={i * (H / 7)} x2={W} y2={i * (H / 7)} stroke="rgba(99,130,255,0.05)" strokeWidth={1} />
            ))}
            {Array.from({ length: 10 }).map((_, i) => (
              <line key={`v${i}`} x1={i * (W / 9)} y1={0} x2={i * (W / 9)} y2={H} stroke="rgba(99,130,255,0.05)" strokeWidth={1} />
            ))}

            {/* Connections */}
            {connections.map(([a, b], i) => {
              const agA = MOCK_AGENTS.find(x => x.id === a);
              const agB = MOCK_AGENTS.find(x => x.id === b);
              if (!agA || !agB) return null;
              const x1 = agA.x / 100 * W, y1 = agA.y / 100 * H;
              const x2 = agB.x / 100 * W, y2 = agB.y / 100 * H;
              return (
                <g key={i}>
                  <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="rgba(99,130,255,0.2)" strokeWidth={1.5} />
                  <line x1={x1} y1={y1} x2={x2} y2={y2}
                    stroke="#6382ff" strokeWidth={2} strokeDasharray="8 4"
                    style={{ animation: `data-flow ${2 + i * 0.3}s linear infinite`, strokeDashoffset: 100 }}
                    opacity={0.6} />
                </g>
              );
            })}

            {/* Nodes */}
            {MOCK_AGENTS.map(agent => {
              const cx = agent.x / 100 * W;
              const cy = agent.y / 100 * H;
              const isSelected = selected?.id === agent.id;
              return (
                <g key={agent.id} onClick={() => setSelected(agent)} style={{ cursor: "pointer" }}>
                  <circle cx={cx} cy={cy} r={isSelected ? 28 : 22} fill={`${agent.color}20`} stroke={agent.color} strokeWidth={isSelected ? 2.5 : 1.5} />
                  {agent.status === "collaborating" && (
                    <circle cx={cx} cy={cy} r={32} fill="none" stroke={agent.color} strokeWidth={1} strokeDasharray="4 4"
                      style={{ animation: "spin-slow 6s linear infinite" }} opacity={0.5} />
                  )}
                  <text x={cx} y={cy + 1} textAnchor="middle" dominantBaseline="middle"
                    fill={agent.color} fontSize={13} fontWeight={700} fontFamily="Syne">{agent.name[0]}</text>
                  <circle cx={cx + 14} cy={cy - 14} r={5} fill={STATUS_COLOR[agent.status]} />
                  <text x={cx} y={cy + 36} textAnchor="middle" fill="rgba(226,232,240,0.7)" fontSize={11} fontFamily="Space Grotesk">{agent.name}</text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Agent Details */}
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 12 }}>
          {selected ? (
            <div style={{ background: "var(--surface2)", borderRadius: 20, padding: 24, border: `1px solid ${selected.color}40` }}>
              <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 16 }}>
                <div style={{ width: 48, height: 48, borderRadius: 14, background: selected.color, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "Syne", fontWeight: 800, fontSize: 20, boxShadow: `0 0 24px ${selected.color}50` }}>{selected.name[0]}</div>
                <div>
                  <div style={{ fontFamily: "Syne", fontSize: 18, fontWeight: 700 }}>{selected.name}</div>
                  <div style={{ fontSize: 12, color: "var(--text2)" }}>{selected.role} · {selected.owner}</div>
                </div>
              </div>
              {[
                { label: "Reputation", value: `${selected.reputation}/5.0` },
                { label: "Tasks", value: selected.tasks },
                { label: "Memories", value: selected.memories.toLocaleString() },
                { label: "COG Earned", value: `${selected.cog.toLocaleString()} COG` },
              ].map(row => (
                <div key={row.label} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid var(--border)", fontSize: 13 }}>
                  <span style={{ color: "var(--text2)" }}>{row.label}</span>
                  <span style={{ fontWeight: 600 }}>{row.value}</span>
                </div>
              ))}
            </div>
          ) : (
            <div style={{ background: "var(--surface2)", borderRadius: 20, padding: 24, border: "1px solid var(--border)", color: "var(--text3)", textAlign: "center", paddingTop: 60 }}>
              Click an agent node to view details
            </div>
          )}

          <div style={{ background: "var(--surface2)", borderRadius: 20, padding: 20, border: "1px solid var(--border)" }}>
            <div style={{ fontSize: 12, fontFamily: "JetBrains Mono", color: "var(--text2)", marginBottom: 12 }}>LEGEND</div>
            {Object.entries(STATUS_COLOR).map(([k, v]) => (
              <div key={k} style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, marginBottom: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: "50%", background: v }} />
                <span style={{ color: "var(--text2)", textTransform: "capitalize" }}>{k}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function MemoryPanel() {
  return (
    <div style={{ padding: 32 }}>
      <div style={{ fontFamily: "Syne", fontSize: 28, fontWeight: 800, marginBottom: 8 }}>Cognitive Memory</div>
      <div style={{ color: "var(--text2)", fontSize: 14, marginBottom: 24 }}>Persistent memories stored using Ebbinghaus forgetting curves</div>

      <div style={{ display: "flex", gap: 16, marginBottom: 24 }}>
        {Object.entries(MEMORY_COLOR).map(([type, color]) => (
          <div key={type} style={{ flex: 1, background: "var(--surface2)", borderRadius: 14, padding: 16, border: `1px solid ${color}30`, textAlign: "center" }}>
            <div style={{ width: 10, height: 10, borderRadius: "50%", background: color, margin: "0 auto 8px" }} />
            <div style={{ fontSize: 11, color: color, fontFamily: "JetBrains Mono", textTransform: "uppercase" }}>{type}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {MOCK_MEMORIES.map(mem => (
          <div key={mem.id} style={{
            background: "var(--surface2)", borderRadius: 16, padding: 20,
            border: `1px solid ${MEMORY_COLOR[mem.type]}30`,
            animation: "appear 0.3s ease",
          }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
              <div style={{
                width: 36, height: 36, borderRadius: 10, background: `${MEMORY_COLOR[mem.type]}20`,
                border: `1px solid ${MEMORY_COLOR[mem.type]}40`,
                display: "flex", alignItems: "center", justifyContent: "center",
                color: MEMORY_COLOR[mem.type], fontSize: 16, flexShrink: 0,
              }}>◎</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", gap: 8, marginBottom: 6, alignItems: "center" }}>
                  <span style={{ fontSize: 10, fontFamily: "JetBrains Mono", padding: "2px 8px", borderRadius: 6, background: `${MEMORY_COLOR[mem.type]}20`, color: MEMORY_COLOR[mem.type] }}>{mem.type}</span>
                  <span style={{ fontSize: 11, color: "var(--text3)" }}>{mem.time}</span>
                </div>
                <div style={{ fontSize: 14, lineHeight: 1.6, marginBottom: 10 }}>{mem.content}</div>
                <div style={{ display: "flex", gap: 16 }}>
                  {[["Importance", mem.importance, "#f59e0b"], ["Strength", mem.strength, "#34d399"]].map(([label, val, color]) => (
                    <div key={label} style={{ display: "flex", alignItems: "center", gap: 8 }}>
                      <span style={{ fontSize: 11, color: "var(--text3)" }}>{label}</span>
                      <div style={{ width: 80, height: 4, borderRadius: 4, background: "var(--surface3)", overflow: "hidden" }}>
                        <div style={{ height: "100%", width: `${val * 100}%`, background: color, borderRadius: 4 }} />
                      </div>
                      <span style={{ fontSize: 11, color, fontFamily: "JetBrains Mono" }}>{(val * 100).toFixed(0)}%</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function MarketplacePanel() {
  return (
    <div style={{ padding: 32 }}>
      <div style={{ fontFamily: "Syne", fontSize: 28, fontWeight: 800, marginBottom: 8 }}>Task Marketplace</div>
      <div style={{ color: "var(--text2)", fontSize: 14, marginBottom: 24 }}>Agents bid on tasks and earn COG tokens for successful completion</div>

      <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
        {MOCK_TASKS.map(task => (
          <div key={task.id} style={{
            background: "var(--surface2)", borderRadius: 16, padding: 20,
            border: "1px solid var(--border)", display: "flex", alignItems: "center", gap: 20,
          }}>
            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <div style={{ fontWeight: 600, fontSize: 16 }}>{task.title}</div>
                <div style={{
                  fontSize: 10, fontFamily: "JetBrains Mono", padding: "2px 8px", borderRadius: 6,
                  background: task.status === "bidding" ? "rgba(245,158,11,0.15)" : "rgba(52,211,153,0.15)",
                  color: task.status === "bidding" ? "#f59e0b" : "#34d399",
                }}>{task.status.toUpperCase()}</div>
              </div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {task.capabilities.map(cap => (
                  <span key={cap} style={{ fontSize: 11, fontFamily: "JetBrains Mono", padding: "3px 8px", borderRadius: 6, background: "var(--surface3)", color: "var(--text2)" }}>{cap}</span>
                ))}
                <span style={{ fontSize: 11, color: "var(--text3)" }}>Posted by {task.poster}</span>
              </div>
            </div>
            <div style={{ textAlign: "right" }}>
              <div style={{ fontFamily: "Syne", fontSize: 24, fontWeight: 700, color: "#f59e0b" }}>{task.reward}</div>
              <div style={{ fontSize: 11, color: "var(--text3)", marginBottom: 8 }}>COG reward</div>
              <div style={{ fontSize: 12, color: "var(--text2)" }}>{task.bids} bids</div>
            </div>
            <button style={{
              background: "linear-gradient(135deg, #6382ff, #a78bfa)", border: "none", borderRadius: 10,
              padding: "10px 18px", color: "white", fontWeight: 600, cursor: "pointer",
              fontFamily: "Space Grotesk", fontSize: 13, flexShrink: 0,
            }}>Bid →</button>
          </div>
        ))}
      </div>

      <div style={{ background: "var(--surface2)", borderRadius: 20, padding: 24, border: "1px solid var(--border)", marginTop: 24 }}>
        <div style={{ fontFamily: "Syne", fontSize: 18, fontWeight: 700, marginBottom: 16 }}>COG Token Economy</div>
        <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
          {[
            { label: "Total Supply", value: "100,000,000 COG", color: "#6382ff" },
            { label: "Circulating", value: "8,400,000 COG", color: "#34d399" },
            { label: "Network Fee", value: "2.5% per task", color: "#f59e0b" },
            { label: "Agent Rewards", value: "40% allocation", color: "#a78bfa" },
          ].map(item => (
            <div key={item.label} style={{ flex: 1, minWidth: 150, padding: "14px 16px", borderRadius: 12, background: `${item.color}10`, border: `1px solid ${item.color}20` }}>
              <div style={{ fontSize: 11, color: "var(--text3)", fontFamily: "JetBrains Mono", marginBottom: 4 }}>{item.label}</div>
              <div style={{ fontWeight: 700, color: item.color }}>{item.value}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function PitchPanel() {
  const slides = [
    {
      title: "The Problem",
      color: "#f87171",
      content: "AI assistants forget you every conversation. Your data is owned by corporations. Agents work in isolation. Humans pay subscriptions — AI companies get rich.",
      stat: "3B+ people use AI tools that reset daily",
    },
    {
      title: "The Solution",
      color: "#34d399",
      content: "Life++ gives every person a persistent AI agent they own. It remembers everything, works while you sleep, and earns money by serving the network.",
      stat: "Your agent. Your data. Your earnings.",
    },
    {
      title: "The Technology",
      color: "#6382ff",
      content: "5-layer architecture: P2P network + LACP protocol + cognitive memory (4 types) + agent runtime + application layer. Built on libp2p + vector DB + Ed25519 identity.",
      stat: "Open source. Permissionless. Unstoppable.",
    },
    {
      title: "The Market",
      color: "#f59e0b",
      content: "AI market: $1.8T by 2030. No player owns the individual AI agent category. Early mover advantage with open protocol creates winner-take-all network effects.",
      stat: "$1.8T TAM · Network effects moat",
    },
    {
      title: "Business Model",
      color: "#a78bfa",
      content: "2.5% marketplace fee on all COG task settlements. Premium relay node infrastructure. Enterprise multi-agent orchestration. Developer SDK licensing.",
      stat: "Target $50M ARR by Year 3",
    },
    {
      title: "The Vision",
      color: "#34d399",
      content: "Phase 1: Personal agents (2026). Phase 2: Agent networks (2027-28). Phase 3: Cognitive Internet — the AI layer of the web. Every human, a cognitive sovereign.",
      stat: '"The internet gave everyone a voice. Life++ gives everyone a mind."',
    },
  ];

  return (
    <div style={{ padding: 32 }}>
      <div style={{ fontFamily: "Syne", fontSize: 28, fontWeight: 800, marginBottom: 8 }}>Venture Capital Pitch</div>
      <div style={{ color: "var(--text2)", fontSize: 14, marginBottom: 24 }}>Seeking $8M Seed · Lead: Tier 1 AI/Web3 VC · Q2 2026</div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 16 }}>
        {slides.map((slide, i) => (
          <div key={i} style={{
            background: "var(--surface2)", borderRadius: 20, padding: 28,
            border: `1px solid ${slide.color}30`, position: "relative", overflow: "hidden",
          }}>
            <div style={{ position: "absolute", top: -20, right: -20, width: 80, height: 80, borderRadius: "50%", background: `${slide.color}10` }} />
            <div style={{ fontSize: 11, fontFamily: "JetBrains Mono", color: slide.color, marginBottom: 10 }}>0{i + 1}</div>
            <div style={{ fontFamily: "Syne", fontSize: 20, fontWeight: 700, marginBottom: 12, color: slide.color }}>{slide.title}</div>
            <div style={{ fontSize: 14, lineHeight: 1.7, color: "var(--text2)", marginBottom: 16 }}>{slide.content}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "var(--text)", padding: "10px 14px", borderRadius: 10, background: `${slide.color}15`, borderLeft: `3px solid ${slide.color}` }}>
              {slide.stat}
            </div>
          </div>
        ))}
      </div>

      <div style={{ background: "var(--surface2)", borderRadius: 20, padding: 28, border: "1px solid var(--border)", marginTop: 20 }}>
        <div style={{ fontFamily: "Syne", fontSize: 20, fontWeight: 700, marginBottom: 20 }}>Funding Ask</div>
        <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
          {[
            { use: "Engineering", pct: "45%", amount: "$3.6M", color: "#6382ff" },
            { use: "Network Growth", pct: "25%", amount: "$2.0M", color: "#34d399" },
            { use: "Research", pct: "15%", amount: "$1.2M", color: "#a78bfa" },
            { use: "Operations", pct: "15%", amount: "$1.2M", color: "#f59e0b" },
          ].map(item => (
            <div key={item.use} style={{ flex: 1, minWidth: 140 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 6 }}>
                <span style={{ color: "var(--text2)" }}>{item.use}</span>
                <span style={{ color: item.color, fontWeight: 600 }}>{item.pct}</span>
              </div>
              <div style={{ height: 6, background: "var(--surface3)", borderRadius: 6, overflow: "hidden" }}>
                <div style={{ height: "100%", width: item.pct, background: item.color, borderRadius: 6 }} />
              </div>
              <div style={{ fontSize: 13, fontFamily: "JetBrains Mono", color: "var(--text2)", marginTop: 4 }}>{item.amount}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── Main App ───────────────────────────────────────────────────────────────

export default function App() {
  const [active, setActive] = useState("overview");

  const panels = {
    overview: <OverviewPanel />,
    agent: <AgentPanel />,
    network: <NetworkPanel />,
    memory: <MemoryPanel />,
    marketplace: <MarketplacePanel />,
    pitch: <PitchPanel />,
  };

  return (
    <>
      <GlobalStyle />
      <div style={{ display: "flex", minHeight: "100vh" }}>
        <Sidebar active={active} setActive={setActive} />
        <div style={{ marginLeft: 72, flex: 1, overflowY: "auto" }}>
          {panels[active]}
        </div>
      </div>
    </>
  );
}
