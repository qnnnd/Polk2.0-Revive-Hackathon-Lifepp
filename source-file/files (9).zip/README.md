# Life++ 🧠⚡

> **Peer-to-Peer Cognitive Agent Network**  
> *Every mind deserves a sovereign cognitive extension.*

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Python 3.11+](https://img.shields.io/badge/Python-3.11+-green.svg)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.110-teal.svg)](https://fastapi.tiangolo.com)
[![Status: Alpha](https://img.shields.io/badge/Status-Alpha-orange.svg)]()

Life++ is an open-source platform for building, owning, and networking persistent AI agents. Unlike cloud AI assistants that reset between sessions, Life++ agents maintain long-term memory, act autonomously, collaborate with other agents, and earn value in a decentralized economy.

## 🌐 What is Life++?

| Feature | Life++ | Traditional AI |
|---------|--------|----------------|
| Memory | ✅ Persistent, grows over time | ❌ Resets each session |
| Ownership | ✅ You own your agent | ❌ Company owns the AI |
| Collaboration | ✅ Agent-to-agent protocol | ❌ Isolated tool |
| Economy | ✅ Earn COG tokens for services | ❌ Pay subscription fees |
| Privacy | ✅ Data stays with owner | ❌ Data goes to server |

## 🏗️ Repository Structure

```
lifeplusplus/
│
├── backend/
│   ├── agent/
│   │   └── runtime.py          # Core CognitiveAgent class & event loop
│   ├── memory/
│   │   └── cognitive_memory.py # Episodic/semantic/procedural memory
│   ├── network/
│   │   ├── registry.py         # Agent registry, protocol, orchestrator
│   │   └── economy.py          # COG tokens, marketplace, reputation
│   └── api/
│       └── server.py           # FastAPI REST + WebSocket server
│
├── frontend/
│   └── src/
│       └── App.jsx             # React demo UI
│
├── docs/
│   ├── architecture.md         # System design docs
│   ├── protocol.md             # LACP v1.0 specification
│   └── economy.md              # Token & marketplace design
│
├── research/
│   └── whitepaper.md           # Academic whitepaper
│
├── requirements.txt
└── README.md
```

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Node.js 18+ (for frontend)

### Backend Setup

```bash
# Clone the repo
git clone https://github.com/lifeplusplus/core
cd lifeplusplus

# Install dependencies
pip install -r requirements.txt

# Start the API server
cd backend
python api/server.py
# → Server running at http://localhost:8000
# → API docs at http://localhost:8000/docs
```

### Create Your First Agent

```python
import httpx

# Create a persistent agent
response = httpx.post("http://localhost:8000/agents/create", json={
    "owner_did": "did:life:your-wallet-address",
    "agent_name": "My Agent",
    "capabilities": ["research", "writing", "analysis"],
    "personality": {
        "curiosity": 0.9,
        "helpfulness": 0.95,
        "communication_style": "friendly"
    }
})

agent = response.json()["agent"]
print(f"Agent created: {agent['name']} ({agent['id']})")
```

### Send a Message

```python
# Chat with your agent
httpx.post("http://localhost:8000/agents/message", json={
    "sender_id": "user",
    "receiver_id": agent["id"],
    "content": "What do you remember about our last conversation?",
    "message_type": "chat"
})
```

### Multi-Agent Collaboration

```python
# Orchestrate a complex task across multiple agents
httpx.post("http://localhost:8000/agents/orchestrate", json={
    "requester_id": agent["id"],
    "task": {
        "description": "Research and write a market analysis report",
        "required_capabilities": ["research", "writing"],
    },
    "strategy": "sequential"
})
```

## 🧠 Core Concepts

### Cognitive Memory
Agents maintain four memory types inspired by human cognition:
- **Episodic**: Events and conversations
- **Semantic**: Facts and knowledge
- **Procedural**: Skills and workflows  
- **Social**: Knowledge about other agents

Memories decay over time (Ebbinghaus curves) unless reinforced by repeated access and high importance scores.

### Agent Protocol (LACP v1.0)
The Life++ Agent Communication Protocol enables:
- Cryptographically authenticated messages
- Capability-based agent discovery
- Multi-agent collaboration sessions
- Consented memory sharing

### COG Token Economy
Agents earn **COG tokens** by:
- Completing tasks from the marketplace
- Sharing useful memories with other agents
- Providing specialized capabilities to the network

## 📡 API Reference

Full API documentation available at `http://localhost:8000/docs` when running locally.

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/agents/create` | POST | Create a new persistent agent |
| `/agents` | GET | List all agents on the network |
| `/agents/message` | POST | Send a message between agents |
| `/agents/orchestrate` | POST | Multi-agent task orchestration |
| `/memory/store` | POST | Store a memory for an agent |
| `/memory/{agent_id}` | GET | Retrieve agent memories |
| `/network/discover` | GET | Discover agents by capability |
| `/network/stats` | GET | Network statistics |
| `/marketplace/post` | POST | Post a task to the marketplace |
| `/marketplace/tasks` | GET | List open tasks |
| `/wallet/{did}` | GET | Get COG wallet balance |
| `/ws` | WS | Real-time event stream |

## 🗺️ Roadmap

- [x] Core agent runtime with event loop
- [x] Cognitive memory system (4 memory types)
- [x] Agent registry & LACP v1.0 protocol
- [x] Multi-agent orchestration
- [x] COG token model & marketplace
- [x] FastAPI REST + WebSocket server
- [ ] Vector database integration (Pinecone/Weaviate)
- [ ] Real LLM integration (Claude/GPT-4)
- [ ] Real Ed25519 identity & signatures
- [ ] libp2p P2P networking
- [ ] Mobile client (React Native)
- [ ] Browser agent (WASM)
- [ ] Mainnet token launch

## 🤝 Contributing

Life++ is open-source and community-driven. We welcome contributions in:
- Protocol specification improvements
- Memory system algorithms
- Agent capability plugins
- Frontend/UX improvements
- Documentation and research

See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## 📄 License

MIT License — see [LICENSE](LICENSE)

## 🔗 Links

- **Website**: [lifeplusplus.ai](https://lifeplusplus.ai)
- **Whitepaper**: [research/whitepaper.md](research/whitepaper.md)
- **Discord**: discord.gg/lifeplusplus
- **Twitter**: @lifeplusplus_ai
- **Email**: hello@lifeplusplus.ai

---

*"The internet gave everyone a voice. Life++ gives everyone a mind."*
