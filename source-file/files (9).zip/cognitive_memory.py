"""
Life++ Cognitive Memory System
Persistent, hierarchical memory for AI agents.

Memory Types:
- Episodic: specific events and interactions
- Semantic: general knowledge and facts
- Procedural: learned skills and workflows
- Social: knowledge about other agents
"""

import asyncio
import json
import uuid
import math
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum


class MemoryType(Enum):
    EPISODIC = "episodic"       # Events, conversations
    SEMANTIC = "semantic"       # Facts, knowledge
    PROCEDURAL = "procedural"   # Skills, workflows
    SOCIAL = "social"           # Agent relationships
    WORKING = "working"         # Short-term context


@dataclass
class MemoryEntry:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    agent_id: str = ""
    content: str = ""
    memory_type: MemoryType = MemoryType.EPISODIC
    embedding: Optional[List[float]] = None
    importance: float = 0.5         # 0.0 - 1.0
    access_count: int = 0
    created_at: datetime = field(default_factory=datetime.utcnow)
    last_accessed: datetime = field(default_factory=datetime.utcnow)
    decay_rate: float = 0.01
    shareable: bool = False
    tags: List[str] = field(default_factory=list)
    linked_memories: List[str] = field(default_factory=list)

    @property
    def current_strength(self) -> float:
        """
        Memory strength using Ebbinghaus forgetting curve:
        R = e^(-t/S) where t=time, S=stability
        Modified by importance and access frequency.
        """
        hours_elapsed = (datetime.utcnow() - self.last_accessed).total_seconds() / 3600
        stability = self.importance * (1 + math.log1p(self.access_count))
        raw_retention = math.exp(-hours_elapsed * self.decay_rate / stability)
        return min(1.0, raw_retention * self.importance)

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "agent_id": self.agent_id,
            "content": self.content,
            "memory_type": self.memory_type.value,
            "importance": self.importance,
            "strength": self.current_strength,
            "access_count": self.access_count,
            "created_at": self.created_at.isoformat(),
            "last_accessed": self.last_accessed.isoformat(),
            "shareable": self.shareable,
            "tags": self.tags,
        }


class CognitiveMemorySystem:
    """
    Biologically-inspired memory system with consolidation,
    forgetting curves, and associative retrieval.
    """

    def __init__(self, vector_store=None, persistence_backend=None):
        self.vector_store = vector_store
        self.persistence = persistence_backend
        # In-memory store for prototype (replace with vector DB in production)
        self._memories: Dict[str, Dict[str, MemoryEntry]] = {}  # agent_id -> {mem_id -> entry}
        self._working_memory: Dict[str, List[MemoryEntry]] = {}  # agent_id -> recent list
        self.working_memory_capacity = 7  # Miller's Law: 7±2

    async def store(
        self,
        agent_id: str,
        content: str,
        memory_type: str = "episodic",
        importance: float = 0.5,
        shareable: bool = False,
        tags: Optional[List[str]] = None,
    ) -> MemoryEntry:
        """Store a new memory for an agent."""
        entry = MemoryEntry(
            agent_id=agent_id,
            content=content,
            memory_type=MemoryType(memory_type),
            importance=importance,
            shareable=shareable,
            tags=tags or [],
        )

        # Generate embedding (mock — replace with real embedding model)
        entry.embedding = await self._generate_embedding(content)

        # Store in memory map
        if agent_id not in self._memories:
            self._memories[agent_id] = {}
        self._memories[agent_id][entry.id] = entry

        # Update working memory
        await self._update_working_memory(agent_id, entry)

        # Persist if backend available
        if self.persistence:
            await self.persistence.save(entry.to_dict())

        # Store in vector DB for semantic search
        if self.vector_store:
            await self.vector_store.upsert(
                id=entry.id,
                vector=entry.embedding,
                metadata=entry.to_dict(),
            )

        return entry

    async def retrieve(
        self,
        query: str,
        agent_id: str,
        top_k: int = 5,
        memory_type: Optional[str] = None,
        shareable_only: bool = False,
        min_strength: float = 0.1,
    ) -> List[Dict]:
        """
        Retrieve memories using semantic similarity + recency + importance.
        """
        query_embedding = await self._generate_embedding(query)

        if agent_id not in self._memories:
            return []

        candidates = list(self._memories[agent_id].values())

        # Filter
        if memory_type:
            candidates = [m for m in candidates if m.memory_type.value == memory_type]
        if shareable_only:
            candidates = [m for m in candidates if m.shareable]
        candidates = [m for m in candidates if m.current_strength >= min_strength]

        # Score each memory
        scored = []
        for memory in candidates:
            similarity = self._cosine_similarity(query_embedding, memory.embedding or [])
            recency_score = 1.0 / (1 + (datetime.utcnow() - memory.last_accessed).total_seconds() / 3600)
            composite_score = (
                0.5 * similarity +
                0.3 * memory.importance +
                0.2 * recency_score
            )
            scored.append((composite_score, memory))

        scored.sort(key=lambda x: x[0], reverse=True)
        top_memories = scored[:top_k]

        # Update access counts
        results = []
        for score, memory in top_memories:
            memory.access_count += 1
            memory.last_accessed = datetime.utcnow()
            result = memory.to_dict()
            result["relevance_score"] = score
            results.append(result)

        return results

    async def consolidate(self, agent_id: str):
        """
        Memory consolidation — runs periodically to:
        1. Decay weak memories
        2. Strengthen frequently-accessed ones
        3. Create associative links between related memories
        4. Prune memories below threshold
        """
        if agent_id not in self._memories:
            return

        memories = list(self._memories[agent_id].values())
        pruned = 0

        for memory in memories:
            if memory.current_strength < 0.05 and memory.importance < 0.3:
                del self._memories[agent_id][memory.id]
                pruned += 1

        # Create associative links between similar memories
        remaining = list(self._memories[agent_id].values())
        for i, mem_a in enumerate(remaining):
            for mem_b in remaining[i+1:]:
                if mem_a.embedding and mem_b.embedding:
                    sim = self._cosine_similarity(mem_a.embedding, mem_b.embedding)
                    if sim > 0.85 and mem_b.id not in mem_a.linked_memories:
                        mem_a.linked_memories.append(mem_b.id)
                        mem_b.linked_memories.append(mem_a.id)

        return {"pruned": pruned, "remaining": len(remaining)}

    async def share_memory(
        self,
        from_agent_id: str,
        to_agent_id: str,
        memory_id: str,
    ) -> Optional[MemoryEntry]:
        """Transfer a shareable memory to another agent."""
        if from_agent_id not in self._memories:
            return None
        if memory_id not in self._memories[from_agent_id]:
            return None

        source = self._memories[from_agent_id][memory_id]
        if not source.shareable:
            return None

        # Create a copy for the receiving agent
        shared = MemoryEntry(
            agent_id=to_agent_id,
            content=f"[Shared by agent {from_agent_id}]: {source.content}",
            memory_type=MemoryType.SOCIAL,
            importance=source.importance * 0.8,  # slight decay on sharing
            shareable=False,
            tags=source.tags + ["shared"],
        )
        shared.embedding = source.embedding

        if to_agent_id not in self._memories:
            self._memories[to_agent_id] = {}
        self._memories[to_agent_id][shared.id] = shared

        return shared

    async def get_memory_stats(self, agent_id: str) -> Dict:
        """Return memory statistics for an agent."""
        if agent_id not in self._memories:
            return {"total": 0}

        memories = list(self._memories[agent_id].values())
        by_type = {}
        for m in memories:
            t = m.memory_type.value
            by_type[t] = by_type.get(t, 0) + 1

        return {
            "total": len(memories),
            "by_type": by_type,
            "avg_strength": sum(m.current_strength for m in memories) / len(memories) if memories else 0,
            "avg_importance": sum(m.importance for m in memories) / len(memories) if memories else 0,
            "shareable_count": sum(1 for m in memories if m.shareable),
        }

    async def _update_working_memory(self, agent_id: str, entry: MemoryEntry):
        """Maintain the working memory buffer (FIFO with importance priority)."""
        if agent_id not in self._working_memory:
            self._working_memory[agent_id] = []

        wm = self._working_memory[agent_id]
        wm.append(entry)

        if len(wm) > self.working_memory_capacity:
            # Remove lowest importance item
            wm.sort(key=lambda m: m.importance)
            wm.pop(0)

    async def _generate_embedding(self, text: str) -> List[float]:
        """
        Generate text embedding vector.
        In production: call OpenAI/Cohere/local embedding model.
        """
        import hashlib
        # Mock embedding — 384-dim vector from hash
        h = hashlib.md5(text.encode()).hexdigest()
        vec = [int(h[i:i+2], 16) / 255.0 for i in range(0, min(len(h), 96), 2)]
        # Normalize
        norm = math.sqrt(sum(x*x for x in vec)) or 1
        return [x / norm for x in vec]

    def _cosine_similarity(self, a: List[float], b: List[float]) -> float:
        """Compute cosine similarity between two vectors."""
        if not a or not b or len(a) != len(b):
            return 0.0
        dot = sum(x*y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x*x for x in a))
        norm_b = math.sqrt(sum(x*x for x in b))
        return dot / (norm_a * norm_b) if norm_a and norm_b else 0.0
