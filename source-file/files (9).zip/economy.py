"""
Life++ Agent Economy
Token model, reputation system, and task marketplace.
"""

import uuid
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum


class TaskStatus(Enum):
    OPEN = "open"
    BIDDING = "bidding"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    REVIEW = "review"
    COMPLETED = "completed"
    DISPUTED = "disputed"
    CANCELLED = "cancelled"


@dataclass
class CogToken:
    """
    COG — The Life++ Network Token
    Used for: agent services, memory storage, task payments, governance
    """
    owner_did: str
    balance: float = 0.0
    staked: float = 0.0
    earned_total: float = 0.0
    spent_total: float = 0.0
    transactions: List[Dict] = field(default_factory=list)

    def transfer(self, to_did: str, amount: float, memo: str = "") -> bool:
        if amount > self.balance:
            return False
        self.balance -= amount
        self.spent_total += amount
        self.transactions.append({
            "type": "send",
            "to": to_did,
            "amount": amount,
            "memo": memo,
            "timestamp": datetime.utcnow().isoformat(),
        })
        return True

    def receive(self, from_did: str, amount: float, memo: str = ""):
        self.balance += amount
        self.earned_total += amount
        self.transactions.append({
            "type": "receive",
            "from": from_did,
            "amount": amount,
            "memo": memo,
            "timestamp": datetime.utcnow().isoformat(),
        })

    def stake(self, amount: float) -> bool:
        if amount > self.balance:
            return False
        self.balance -= amount
        self.staked += amount
        return True


@dataclass
class TaskListing:
    """A task posted on the Life++ marketplace."""
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    poster_did: str = ""
    title: str = ""
    description: str = ""
    required_capabilities: List[str] = field(default_factory=list)
    reward_cog: float = 0.0
    deadline_hours: int = 24
    status: TaskStatus = TaskStatus.OPEN
    assigned_agent_id: Optional[str] = None
    bids: List[Dict] = field(default_factory=list)
    result: Optional[Dict] = None
    created_at: datetime = field(default_factory=datetime.utcnow)
    quality_score: Optional[float] = None

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "poster_did": self.poster_did,
            "title": self.title,
            "description": self.description,
            "required_capabilities": self.required_capabilities,
            "reward_cog": self.reward_cog,
            "deadline_hours": self.deadline_hours,
            "status": self.status.value,
            "assigned_agent_id": self.assigned_agent_id,
            "bid_count": len(self.bids),
            "created_at": self.created_at.isoformat(),
        }


class TaskMarketplace:
    """
    Decentralized task marketplace where agents can discover
    and bid on tasks, earning COG tokens for successful completion.
    """

    def __init__(self, ledger: "TokenLedger"):
        self.ledger = ledger
        self._tasks: Dict[str, TaskListing] = {}
        self._escrow: Dict[str, float] = {}  # task_id -> escrowed COG

    async def post_task(
        self,
        poster_did: str,
        title: str,
        description: str,
        required_capabilities: List[str],
        reward_cog: float,
        deadline_hours: int = 24,
    ) -> TaskListing:
        """Post a new task to the marketplace."""
        # Escrow the reward
        wallet = self.ledger.get_wallet(poster_did)
        if not wallet or wallet.balance < reward_cog:
            raise ValueError("Insufficient COG balance to post task")

        task = TaskListing(
            poster_did=poster_did,
            title=title,
            description=description,
            required_capabilities=required_capabilities,
            reward_cog=reward_cog,
            deadline_hours=deadline_hours,
        )

        wallet.transfer("escrow", reward_cog, f"Escrow for task {task.id[:8]}")
        self._escrow[task.id] = reward_cog
        self._tasks[task.id] = task

        print(f"📋 Task posted: '{title}' ({reward_cog} COG reward)")
        return task

    async def submit_bid(
        self,
        task_id: str,
        agent_id: str,
        agent_did: str,
        bid_amount: float,
        proposal: str,
        estimated_hours: float,
    ) -> bool:
        """An agent submits a bid for a task."""
        task = self._tasks.get(task_id)
        if not task or task.status != TaskStatus.OPEN:
            return False

        bid = {
            "agent_id": agent_id,
            "agent_did": agent_did,
            "bid_amount": bid_amount,
            "proposal": proposal,
            "estimated_hours": estimated_hours,
            "submitted_at": datetime.utcnow().isoformat(),
        }
        task.bids.append(bid)
        if task.status == TaskStatus.OPEN:
            task.status = TaskStatus.BIDDING

        print(f"  📨 Bid from {agent_id[:8]}: {bid_amount} COG — '{proposal[:50]}'")
        return True

    async def assign_task(
        self,
        task_id: str,
        agent_id: str,
        poster_did: str,
    ) -> bool:
        """Task poster selects a winning agent."""
        task = self._tasks.get(task_id)
        if not task or task.poster_did != poster_did:
            return False

        bid = next((b for b in task.bids if b["agent_id"] == agent_id), None)
        if not bid:
            return False

        task.assigned_agent_id = agent_id
        task.status = TaskStatus.ASSIGNED
        print(f"✅ Task {task_id[:8]} assigned to agent {agent_id[:8]}")
        return True

    async def complete_task(
        self,
        task_id: str,
        agent_id: str,
        result: Dict,
        quality_score: float,
    ) -> Dict:
        """
        Mark task complete, release escrow, update reputation.
        Network fee: 2.5% of reward goes to protocol treasury.
        """
        task = self._tasks.get(task_id)
        if not task or task.assigned_agent_id != agent_id:
            return {"error": "Unauthorized or task not found"}

        task.status = TaskStatus.COMPLETED
        task.result = result
        task.quality_score = quality_score

        # Release payment from escrow
        escrowed = self._escrow.pop(task_id, 0)
        network_fee = escrowed * 0.025
        agent_payment = escrowed - network_fee

        agent_record = next(
            (b for b in task.bids if b["agent_id"] == agent_id), {}
        )
        agent_did = agent_record.get("agent_did", "unknown")

        wallet = self.ledger.get_or_create_wallet(agent_did)
        wallet.receive("escrow", agent_payment, f"Task completion: {task.title[:30]}")

        print(f"💰 Task {task_id[:8]} complete — {agent_payment:.2f} COG paid to {agent_id[:8]}")
        print(f"   Network fee: {network_fee:.4f} COG | Quality: {quality_score:.1f}/5.0")

        return {
            "task_id": task_id,
            "payment": agent_payment,
            "network_fee": network_fee,
            "quality_score": quality_score,
        }

    def get_open_tasks(
        self,
        capability_filter: Optional[str] = None,
    ) -> List[Dict]:
        """List available tasks on the marketplace."""
        tasks = [t for t in self._tasks.values() if t.status in (TaskStatus.OPEN, TaskStatus.BIDDING)]
        if capability_filter:
            tasks = [t for t in tasks if capability_filter in t.required_capabilities]
        return [t.to_dict() for t in sorted(tasks, key=lambda t: t.reward_cog, reverse=True)]


class TokenLedger:
    """Simple in-memory COG token ledger (production: on-chain)."""

    GENESIS_SUPPLY = 100_000_000  # 100M COG total supply
    TREASURY_DID = "did:life:treasury"

    def __init__(self):
        self._wallets: Dict[str, CogToken] = {}
        # Initialize treasury
        treasury = CogToken(owner_did=self.TREASURY_DID, balance=self.GENESIS_SUPPLY)
        self._wallets[self.TREASURY_DID] = treasury

    def get_wallet(self, did: str) -> Optional[CogToken]:
        return self._wallets.get(did)

    def get_or_create_wallet(self, did: str) -> CogToken:
        if did not in self._wallets:
            self._wallets[did] = CogToken(owner_did=did)
        return self._wallets[did]

    def faucet(self, did: str, amount: float = 100.0) -> bool:
        """Developer faucet — testnet only."""
        treasury = self._wallets[self.TREASURY_DID]
        wallet = self.get_or_create_wallet(did)
        if treasury.balance >= amount:
            treasury.balance -= amount
            wallet.receive(self.TREASURY_DID, amount, "Faucet")
            return True
        return False

    def total_circulating(self) -> float:
        return sum(
            w.balance + w.staked
            for did, w in self._wallets.items()
            if did != self.TREASURY_DID
        )

    def get_stats(self) -> Dict:
        return {
            "total_supply": self.GENESIS_SUPPLY,
            "circulating": self.total_circulating(),
            "treasury_balance": self._wallets[self.TREASURY_DID].balance,
            "wallet_count": len(self._wallets) - 1,
        }
