"""
Life++ Agent Registry & P2P Network Layer
Decentralized agent discovery, routing, and communication protocol.
"""

import asyncio
import uuid
import json
import hashlib
from datetime import datetime
from typing import Any, Dict, List, Optional, Set
from dataclasses import dataclass, field


# ─────────────────────────────────────────────
# AGENT REGISTRY (Decentralized DHT-style)
# ─────────────────────────────────────────────

@dataclass
class AgentRecord:
    """An agent's public registration record on the network."""
    agent_id: str
    owner_did: str
    agent_name: str
    endpoint: str                          # WebSocket/HTTP endpoint
    capabilities: List[str] = field(default_factory=list)
    reputation: float = 1.0
    is_online: bool = False
    registered_at: datetime = field(default_factory=datetime.utcnow)
    last_heartbeat: datetime = field(default_factory=datetime.utcnow)
    public_key: str = ""
    service_fees: Dict[str, float] = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "agent_id": self.agent_id,
            "owner_did": self.owner_did,
            "agent_name": self.agent_name,
            "endpoint": self.endpoint,
            "capabilities": self.capabilities,
            "reputation": self.reputation,
            "is_online": self.is_online,
            "registered_at": self.registered_at.isoformat(),
            "last_heartbeat": self.last_heartbeat.isoformat(),
            "service_fees": self.service_fees,
        }


class AgentRegistry:
    """
    Decentralized agent registry using a DHT-inspired architecture.
    In production, this is distributed across network nodes.
    """

    def __init__(self):
        self._agents: Dict[str, AgentRecord] = {}
        self._capability_index: Dict[str, Set[str]] = {}  # capability -> {agent_ids}
        self._owner_index: Dict[str, List[str]] = {}       # owner_did -> [agent_ids]

    async def register(
        self,
        agent_id: str,
        owner_did: str,
        agent_name: str,
        endpoint: str,
        capabilities: List[str],
        public_key: str = "",
        service_fees: Optional[Dict[str, float]] = None,
    ) -> AgentRecord:
        """Register a new agent on the network."""
        record = AgentRecord(
            agent_id=agent_id,
            owner_did=owner_did,
            agent_name=agent_name,
            endpoint=endpoint,
            capabilities=capabilities,
            public_key=public_key,
            service_fees=service_fees or {},
            is_online=True,
        )

        self._agents[agent_id] = record

        # Update capability index
        for cap in capabilities:
            if cap not in self._capability_index:
                self._capability_index[cap] = set()
            self._capability_index[cap].add(agent_id)

        # Update owner index
        if owner_did not in self._owner_index:
            self._owner_index[owner_did] = []
        self._owner_index[owner_did].append(agent_id)

        print(f"✓ Agent '{agent_name}' ({agent_id[:8]}...) registered on Life++ network")
        return record

    async def discover(
        self,
        capability: Optional[str] = None,
        owner_did: Optional[str] = None,
        online_only: bool = True,
        min_reputation: float = 0.5,
    ) -> List[AgentRecord]:
        """Discover agents by capability, owner, or reputation."""
        candidates = list(self._agents.values())

        if capability:
            agent_ids = self._capability_index.get(capability, set())
            candidates = [a for a in candidates if a.agent_id in agent_ids]

        if owner_did:
            candidates = [a for a in candidates if a.owner_did == owner_did]

        if online_only:
            candidates = [a for a in candidates if a.is_online]

        candidates = [a for a in candidates if a.reputation >= min_reputation]

        return sorted(candidates, key=lambda a: a.reputation, reverse=True)

    async def heartbeat(self, agent_id: str):
        """Update agent's heartbeat timestamp."""
        if agent_id in self._agents:
            self._agents[agent_id].last_heartbeat = datetime.utcnow()
            self._agents[agent_id].is_online = True

    async def update_reputation(self, agent_id: str, delta: float, reason: str = ""):
        """Update an agent's reputation score based on task outcomes."""
        if agent_id in self._agents:
            record = self._agents[agent_id]
            record.reputation = max(0.0, min(5.0, record.reputation + delta))
            print(f"Reputation update for {agent_id[:8]}: {delta:+.2f} ({reason})")

    async def deregister(self, agent_id: str):
        """Remove an agent from the registry."""
        if agent_id in self._agents:
            record = self._agents.pop(agent_id)
            for cap in record.capabilities:
                self._capability_index.get(cap, set()).discard(agent_id)
            owner_list = self._owner_index.get(record.owner_did, [])
            if agent_id in owner_list:
                owner_list.remove(agent_id)

    def get_network_stats(self) -> Dict:
        agents = list(self._agents.values())
        return {
            "total_agents": len(agents),
            "online_agents": sum(1 for a in agents if a.is_online),
            "unique_owners": len(self._owner_index),
            "total_capabilities": len(self._capability_index),
            "avg_reputation": sum(a.reputation for a in agents) / len(agents) if agents else 0,
        }


# ─────────────────────────────────────────────
# AGENT PROTOCOL — Message Routing
# ─────────────────────────────────────────────

class AgentProtocol:
    """
    Life++ Agent Communication Protocol (LACP v1.0)
    Handles secure, authenticated message routing between agents.
    """

    VERSION = "1.0.0"
    MAGIC_BYTES = b"LIFE++"

    def __init__(self, registry: AgentRegistry):
        self.registry = registry
        self._message_handlers: Dict[str, Any] = {}
        self._pending_responses: Dict[str, asyncio.Future] = {}

    def encode_message(
        self,
        sender_id: str,
        receiver_id: str,
        message_type: str,
        content: Any,
        signature: str = "",
    ) -> bytes:
        """Encode a message to wire format."""
        payload = {
            "version": self.VERSION,
            "sender_id": sender_id,
            "receiver_id": receiver_id,
            "message_type": message_type,
            "content": content,
            "timestamp": datetime.utcnow().isoformat(),
            "nonce": str(uuid.uuid4()),
            "signature": signature,
        }
        data = json.dumps(payload).encode()
        return self.MAGIC_BYTES + len(data).to_bytes(4, "big") + data

    def decode_message(self, data: bytes) -> Optional[Dict]:
        """Decode a wire-format message."""
        if not data.startswith(self.MAGIC_BYTES):
            return None
        length = int.from_bytes(data[6:10], "big")
        payload = json.loads(data[10:10+length])
        return payload

    async def route_message(
        self,
        sender_id: str,
        receiver_id: str,
        message_type: str,
        content: Any,
    ) -> Optional[Dict]:
        """Route a message to the target agent."""
        agents = await self.registry.discover(online_only=False)
        target = next((a for a in agents if a.agent_id == receiver_id), None)

        if not target:
            return {"error": f"Agent {receiver_id} not found on network"}

        # In production: establish WebSocket connection to target.endpoint
        # and send encoded message. For prototype, use in-process routing.
        message_id = str(uuid.uuid4())
        print(f"→ Routing {message_type} from {sender_id[:8]} to {receiver_id[:8]}")

        return {
            "routed": True,
            "message_id": message_id,
            "target_endpoint": target.endpoint,
        }

    async def broadcast(
        self,
        sender_id: str,
        message_type: str,
        content: Any,
        capability_filter: Optional[str] = None,
    ) -> List[str]:
        """Broadcast a message to all (or filtered) agents on the network."""
        targets = await self.registry.discover(
            capability=capability_filter,
            online_only=True,
        )
        routed_to = []
        for target in targets:
            if target.agent_id != sender_id:
                await self.route_message(sender_id, target.agent_id, message_type, content)
                routed_to.append(target.agent_id)
        return routed_to


# ─────────────────────────────────────────────
# MULTI-AGENT ORCHESTRATOR
# ─────────────────────────────────────────────

class MultiAgentOrchestrator:
    """
    Coordinates multi-agent task execution.
    Decomposes complex tasks and assigns to specialized agents.
    """

    def __init__(self, registry: AgentRegistry, protocol: AgentProtocol):
        self.registry = registry
        self.protocol = protocol
        self.active_sessions: Dict[str, Dict] = {}

    async def orchestrate(
        self,
        requester_id: str,
        task: Dict,
        strategy: str = "parallel",
    ) -> Dict:
        """
        Orchestrate a multi-agent task.

        Strategies:
        - parallel: All agents work simultaneously on sub-tasks
        - sequential: Agents pass results along a pipeline
        - competitive: Best result wins (quality selection)
        - consensus: Agents vote/agree on final answer
        """
        session_id = str(uuid.uuid4())
        required_capabilities = task.get("required_capabilities", [])

        # Discover suitable agents
        available_agents = []
        for cap in required_capabilities:
            agents = await self.registry.discover(
                capability=cap,
                online_only=True,
                min_reputation=0.5,
            )
            available_agents.extend(agents)

        # Remove duplicates
        seen = set()
        unique_agents = []
        for a in available_agents:
            if a.agent_id not in seen:
                seen.add(a.agent_id)
                unique_agents.append(a)

        if not unique_agents:
            return {"error": "No suitable agents found for this task"}

        # Create collaboration session
        session = {
            "session_id": session_id,
            "requester_id": requester_id,
            "task": task,
            "strategy": strategy,
            "agents": [a.agent_id for a in unique_agents],
            "started_at": datetime.utcnow().isoformat(),
            "status": "running",
            "results": [],
        }
        self.active_sessions[session_id] = session

        print(f"\n🤝 Multi-agent session {session_id[:8]} started")
        print(f"   Strategy: {strategy}")
        print(f"   Agents: {[a.agent_name for a in unique_agents]}")

        # Execute based on strategy
        if strategy == "parallel":
            results = await self._parallel_execute(session, unique_agents, task)
        elif strategy == "sequential":
            results = await self._sequential_execute(session, unique_agents, task)
        else:
            results = await self._parallel_execute(session, unique_agents, task)

        session["results"] = results
        session["status"] = "completed"
        session["completed_at"] = datetime.utcnow().isoformat()

        return {
            "session_id": session_id,
            "strategy": strategy,
            "agents_involved": len(unique_agents),
            "results": results,
        }

    async def _parallel_execute(
        self,
        session: Dict,
        agents: List[AgentRecord],
        task: Dict,
    ) -> List[Dict]:
        """Execute task in parallel across all agents."""
        # Simulate parallel execution
        results = []
        for agent in agents:
            result = {
                "agent_id": agent.agent_id,
                "agent_name": agent.agent_name,
                "contribution": f"{agent.agent_name} completed sub-task",
                "timestamp": datetime.utcnow().isoformat(),
            }
            results.append(result)
            await asyncio.sleep(0.1)  # Simulate processing time
        return results

    async def _sequential_execute(
        self,
        session: Dict,
        agents: List[AgentRecord],
        task: Dict,
    ) -> List[Dict]:
        """Pass task output through a chain of agents."""
        results = []
        context = task.copy()

        for agent in agents:
            result = {
                "agent_id": agent.agent_id,
                "agent_name": agent.agent_name,
                "input": context,
                "output": f"{agent.agent_name} processed and enhanced the task",
                "timestamp": datetime.utcnow().isoformat(),
            }
            results.append(result)
            context["previous_output"] = result["output"]
            await asyncio.sleep(0.1)

        return results
