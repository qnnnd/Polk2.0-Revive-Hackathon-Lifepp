"""
Life++ Agent Runtime
Core execution engine for persistent cognitive agents.
"""

import asyncio
import uuid
import json
from datetime import datetime
from typing import Any, Dict, List, Optional, Callable
from dataclasses import dataclass, field
from enum import Enum


class AgentStatus(Enum):
    IDLE = "idle"
    THINKING = "thinking"
    EXECUTING = "executing"
    COLLABORATING = "collaborating"
    SLEEPING = "sleeping"


class MessageType(Enum):
    CHAT = "chat"
    TASK = "task"
    COLLABORATE = "collaborate"
    MEMORY_SYNC = "memory_sync"
    HEARTBEAT = "heartbeat"
    RESULT = "result"


@dataclass
class AgentMessage:
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    sender_id: str = ""
    receiver_id: str = ""
    message_type: MessageType = MessageType.CHAT
    content: Any = None
    timestamp: datetime = field(default_factory=datetime.utcnow)
    metadata: Dict = field(default_factory=dict)

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "sender_id": self.sender_id,
            "receiver_id": self.receiver_id,
            "message_type": self.message_type.value,
            "content": self.content,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }


@dataclass
class AgentCapability:
    name: str
    description: str
    handler: Callable
    cost_per_call: float = 0.0
    requires_memory: bool = False


class CognitiveAgent:
    """
    A persistent, memory-augmented AI agent that can communicate,
    collaborate, and grow over time within the Life++ network.
    """

    def __init__(
        self,
        owner_did: str,
        agent_name: str,
        personality: Optional[Dict] = None,
        memory_backend=None,
        network_client=None,
    ):
        self.id = str(uuid.uuid4())
        self.owner_did = owner_did
        self.name = agent_name
        self.status = AgentStatus.IDLE
        self.personality = personality or self._default_personality()
        self.memory = memory_backend
        self.network = network_client
        self.capabilities: Dict[str, AgentCapability] = {}
        self.inbox: asyncio.Queue = asyncio.Queue()
        self.outbox: asyncio.Queue = asyncio.Queue()
        self.created_at = datetime.utcnow()
        self.last_active = datetime.utcnow()
        self.reputation_score = 1.0
        self.task_history: List[Dict] = []
        self._running = False

    def _default_personality(self) -> Dict:
        return {
            "curiosity": 0.8,
            "helpfulness": 0.9,
            "creativity": 0.7,
            "caution": 0.6,
            "communication_style": "professional",
        }

    def register_capability(self, capability: AgentCapability):
        """Register a new capability this agent can perform."""
        self.capabilities[capability.name] = capability

    async def think(self, context: str) -> str:
        """
        Core cognitive loop — processes context using memory + LLM reasoning.
        Returns agent's response/decision.
        """
        self.status = AgentStatus.THINKING
        self.last_active = datetime.utcnow()

        # Retrieve relevant memories
        memories = []
        if self.memory:
            memories = await self.memory.retrieve(
                query=context,
                agent_id=self.id,
                top_k=5
            )

        # Build enriched prompt with memory context
        memory_context = "\n".join([
            f"[Memory {i+1}]: {m['content']}"
            for i, m in enumerate(memories)
        ])

        prompt = f"""
You are {self.name}, a persistent AI agent owned by {self.owner_did}.

Your personality traits:
- Curiosity: {self.personality['curiosity']}
- Helpfulness: {self.personality['helpfulness']}
- Style: {self.personality['communication_style']}

Relevant memories:
{memory_context if memory_context else "No relevant memories yet."}

Current context: {context}

Respond thoughtfully, drawing on your memories and personality.
        """

        # Store this interaction as a new memory
        if self.memory:
            await self.memory.store(
                agent_id=self.id,
                content=f"Processed: {context[:200]}",
                memory_type="episodic",
                importance=0.6,
            )

        self.status = AgentStatus.IDLE
        return prompt  # In production, this calls LLM API

    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Handle an incoming message from another agent or user."""
        if message.message_type == MessageType.CHAT:
            response_content = await self.think(str(message.content))
            return AgentMessage(
                sender_id=self.id,
                receiver_id=message.sender_id,
                message_type=MessageType.RESULT,
                content=response_content,
            )

        elif message.message_type == MessageType.TASK:
            return await self._execute_task(message)

        elif message.message_type == MessageType.COLLABORATE:
            return await self._handle_collaboration(message)

        return None

    async def _execute_task(self, message: AgentMessage) -> AgentMessage:
        """Execute a structured task request."""
        self.status = AgentStatus.EXECUTING
        task = message.content

        capability_name = task.get("capability")
        if capability_name and capability_name in self.capabilities:
            cap = self.capabilities[capability_name]
            result = await cap.handler(task.get("params", {}))
        else:
            result = {"error": f"Capability '{capability_name}' not found"}

        self.task_history.append({
            "task": task,
            "result": result,
            "timestamp": datetime.utcnow().isoformat(),
        })

        self.status = AgentStatus.IDLE
        return AgentMessage(
            sender_id=self.id,
            receiver_id=message.sender_id,
            message_type=MessageType.RESULT,
            content=result,
        )

    async def _handle_collaboration(self, message: AgentMessage) -> AgentMessage:
        """Handle a multi-agent collaboration request."""
        self.status = AgentStatus.COLLABORATING
        collab_data = message.content

        # Share relevant memories for collaboration context
        shared_memories = []
        if self.memory:
            shared_memories = await self.memory.retrieve(
                query=collab_data.get("topic", ""),
                agent_id=self.id,
                top_k=3,
                shareable_only=True,
            )

        self.status = AgentStatus.IDLE
        return AgentMessage(
            sender_id=self.id,
            receiver_id=message.sender_id,
            message_type=MessageType.RESULT,
            content={
                "contribution": f"{self.name}'s perspective on the task",
                "shared_memories": shared_memories,
                "capabilities_offered": list(self.capabilities.keys()),
            },
        )

    async def run(self):
        """Main agent event loop."""
        self._running = True
        while self._running:
            try:
                message = await asyncio.wait_for(self.inbox.get(), timeout=1.0)
                response = await self.process_message(message)
                if response:
                    await self.outbox.put(response)
            except asyncio.TimeoutError:
                # Agent heartbeat / background tasks
                await self._background_tasks()
            except Exception as e:
                print(f"Agent {self.name} error: {e}")

    async def _background_tasks(self):
        """Periodic background maintenance."""
        if self.memory:
            await self.memory.consolidate(agent_id=self.id)

    def stop(self):
        self._running = False

    def to_dict(self) -> Dict:
        return {
            "id": self.id,
            "name": self.name,
            "owner_did": self.owner_did,
            "status": self.status.value,
            "reputation_score": self.reputation_score,
            "capabilities": list(self.capabilities.keys()),
            "created_at": self.created_at.isoformat(),
            "last_active": self.last_active.isoformat(),
            "personality": self.personality,
        }
