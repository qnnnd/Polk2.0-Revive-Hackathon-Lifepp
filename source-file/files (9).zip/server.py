"""
Life++ API Server
FastAPI backend exposing agent runtime, memory, registry, and marketplace.
"""

from fastapi import FastAPI, WebSocket, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Any, Dict, List, Optional
import asyncio
import json
import uvicorn

# Internal imports
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from agent.runtime import CognitiveAgent, AgentMessage, MessageType
from memory.cognitive_memory import CognitiveMemorySystem
from network.registry import AgentRegistry, AgentProtocol, MultiAgentOrchestrator
from network.economy import TokenLedger, TaskMarketplace


# ─── App Initialization ───────────────────────────────────

app = FastAPI(
    title="Life++ API",
    description="Peer-to-Peer Cognitive Agent Network",
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Singletons
memory_system = CognitiveMemorySystem()
registry = AgentRegistry()
protocol = AgentProtocol(registry)
orchestrator = MultiAgentOrchestrator(registry, protocol)
ledger = TokenLedger()
marketplace = TaskMarketplace(ledger)
agents: Dict[str, CognitiveAgent] = {}
active_connections: List[WebSocket] = []


# ─── Request / Response Models ────────────────────────────

class CreateAgentRequest(BaseModel):
    owner_did: str
    agent_name: str
    personality: Optional[Dict] = None
    capabilities: List[str] = []
    endpoint: str = "ws://localhost:8000/ws"

class SendMessageRequest(BaseModel):
    sender_id: str
    receiver_id: str
    content: Any
    message_type: str = "chat"

class PostTaskRequest(BaseModel):
    poster_did: str
    title: str
    description: str
    required_capabilities: List[str]
    reward_cog: float
    deadline_hours: int = 24

class StoreMemoryRequest(BaseModel):
    agent_id: str
    content: str
    memory_type: str = "episodic"
    importance: float = 0.5
    shareable: bool = False
    tags: List[str] = []

class OrchestrateRequest(BaseModel):
    requester_id: str
    task: Dict
    strategy: str = "parallel"


# ─── Agent Endpoints ──────────────────────────────────────

@app.post("/agents/create", tags=["Agents"])
async def create_agent(req: CreateAgentRequest, background_tasks: BackgroundTasks):
    """Create and register a new persistent AI agent."""
    agent = CognitiveAgent(
        owner_did=req.owner_did,
        agent_name=req.agent_name,
        personality=req.personality,
        memory_backend=memory_system,
    )
    agents[agent.id] = agent

    # Register on network
    await registry.register(
        agent_id=agent.id,
        owner_did=req.owner_did,
        agent_name=req.agent_name,
        endpoint=req.endpoint,
        capabilities=req.capabilities,
    )

    # Initialize wallet
    wallet = ledger.get_or_create_wallet(req.owner_did)
    if wallet.balance == 0:
        ledger.faucet(req.owner_did, 1000.0)  # Welcome bonus

    # Start agent background loop
    background_tasks.add_task(agent.run)

    return {"success": True, "agent": agent.to_dict()}


@app.get("/agents", tags=["Agents"])
async def list_agents():
    """List all agents on the network."""
    return {"agents": [a.to_dict() for a in agents.values()]}


@app.get("/agents/{agent_id}", tags=["Agents"])
async def get_agent(agent_id: str):
    """Get details for a specific agent."""
    if agent_id not in agents:
        raise HTTPException(status_code=404, detail="Agent not found")
    return agents[agent_id].to_dict()


@app.post("/agents/message", tags=["Agents"])
async def send_message(req: SendMessageRequest):
    """Send a message from one agent to another."""
    if req.receiver_id not in agents:
        raise HTTPException(status_code=404, detail="Receiver agent not found")

    message = AgentMessage(
        sender_id=req.sender_id,
        receiver_id=req.receiver_id,
        message_type=MessageType(req.message_type),
        content=req.content,
    )

    receiver = agents[req.receiver_id]
    await receiver.inbox.put(message)

    return {"success": True, "message_id": message.id}


@app.post("/agents/orchestrate", tags=["Agents"])
async def orchestrate_task(req: OrchestrateRequest):
    """Orchestrate a multi-agent collaborative task."""
    result = await orchestrator.orchestrate(
        requester_id=req.requester_id,
        task=req.task,
        strategy=req.strategy,
    )
    return result


# ─── Memory Endpoints ─────────────────────────────────────

@app.post("/memory/store", tags=["Memory"])
async def store_memory(req: StoreMemoryRequest):
    """Store a memory for an agent."""
    entry = await memory_system.store(
        agent_id=req.agent_id,
        content=req.content,
        memory_type=req.memory_type,
        importance=req.importance,
        shareable=req.shareable,
        tags=req.tags,
    )
    return {"success": True, "memory": entry.to_dict()}


@app.get("/memory/{agent_id}", tags=["Memory"])
async def get_memories(agent_id: str, query: str = "", top_k: int = 10):
    """Retrieve memories for an agent."""
    memories = await memory_system.retrieve(
        query=query,
        agent_id=agent_id,
        top_k=top_k,
    )
    stats = await memory_system.get_memory_stats(agent_id)
    return {"memories": memories, "stats": stats}


# ─── Network Endpoints ────────────────────────────────────

@app.get("/network/discover", tags=["Network"])
async def discover_agents(capability: Optional[str] = None, min_reputation: float = 0.5):
    """Discover agents by capability."""
    records = await registry.discover(
        capability=capability,
        online_only=True,
        min_reputation=min_reputation,
    )
    return {"agents": [r.to_dict() for r in records]}


@app.get("/network/stats", tags=["Network"])
async def network_stats():
    """Get overall network statistics."""
    net_stats = registry.get_network_stats()
    token_stats = ledger.get_stats()
    return {
        "network": net_stats,
        "economy": token_stats,
        "marketplace": {
            "open_tasks": len(marketplace.get_open_tasks()),
        }
    }


# ─── Economy Endpoints ────────────────────────────────────

@app.post("/marketplace/post", tags=["Economy"])
async def post_task(req: PostTaskRequest):
    """Post a task to the marketplace."""
    task = await marketplace.post_task(
        poster_did=req.poster_did,
        title=req.title,
        description=req.description,
        required_capabilities=req.required_capabilities,
        reward_cog=req.reward_cog,
        deadline_hours=req.deadline_hours,
    )
    return {"success": True, "task": task.to_dict()}


@app.get("/marketplace/tasks", tags=["Economy"])
async def list_tasks(capability: Optional[str] = None):
    """List open tasks on the marketplace."""
    return {"tasks": marketplace.get_open_tasks(capability_filter=capability)}


@app.get("/wallet/{did}", tags=["Economy"])
async def get_wallet(did: str):
    """Get wallet balance for a DID."""
    wallet = ledger.get_or_create_wallet(did)
    return {
        "did": did,
        "balance": wallet.balance,
        "staked": wallet.staked,
        "earned_total": wallet.earned_total,
        "spent_total": wallet.spent_total,
    }


# ─── WebSocket for Real-time Updates ─────────────────────

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket for real-time agent events and messages."""
    await websocket.accept()
    active_connections.append(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            event = json.loads(data)
            # Echo back with network stats
            stats = registry.get_network_stats()
            await websocket.send_text(json.dumps({
                "type": "ack",
                "event": event,
                "network_stats": stats,
            }))
    except Exception:
        active_connections.remove(websocket)


async def broadcast_event(event: Dict):
    """Broadcast an event to all connected WebSocket clients."""
    msg = json.dumps(event)
    for ws in active_connections:
        try:
            await ws.send_text(msg)
        except Exception:
            pass


# ─── Root ─────────────────────────────────────────────────

@app.get("/", tags=["System"])
async def root():
    return {
        "name": "Life++",
        "tagline": "Peer-to-Peer Cognitive Agent Network",
        "version": "0.1.0",
        "docs": "/docs",
        "status": "online",
    }


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
